module.exports = {
  'local_secret': 'local_account',
  'local_collection': 'mongodb://localhost/local_account'
}
