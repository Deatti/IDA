module.exports = {  
  facebook : {
    clientId : '337828346723905',
    clientSecret : '951adcf3c87131254b4ab521fd08c1d8',
  },
  google : {
    clientId : '373179483442-qdu2so3q9u38es1r9o93n920ds01p3dg.apps.googleusercontent.com',
    clientSecret : 'uTetykgQlY56RJG910ZSpZIH'
  }
}
