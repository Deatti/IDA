<template>
  <v-app>
  </v-app>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}
</script>
<style scoped>

</style>
