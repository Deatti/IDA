<template>
  <v-layout>
  </v-layout>
</template>
<script>
export default {
  data () {
    return {
      songs: null
    }
  },
  async mounted () {
  },
  methods: {
  }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
