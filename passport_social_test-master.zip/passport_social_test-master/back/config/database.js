module.exports = {
    'local_secret': 'school_social_account',
    'local_collection': 'mongodb://localhost/school_social_account'
  }
  