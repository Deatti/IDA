module.exports = {
    'social_secret': 'account',
    'social_collection' :'mongodb://mongodb/account'
  }
  
