module.exports = {  
  facebook_config: {
      clientID : '337828346723905',
      clientSecret : '951adcf3c87131254b4ab521fd08c1d8',
      callbackURL : 'http://210.114.89.51:80/login/facebook/callback',
      profileFields : ['id','displayName','email']
  },
  google_config: {
    clientID : '373179483442-rotm7v94r1b5pg0v4r1k7glb355viss1.apps.googleusercontent.com',
    clientSecret : 'KRSwvVLolkwvEL_nlaQfziQz',
    callbackURL : 'http://210.114.89.51.xip.io:80/login/google/callback',
  }
  }
  
